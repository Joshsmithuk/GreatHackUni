import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class project_hack2 extends PApplet {

enum gameModes{Starting, Lost}
gameModes current;


int quest=1;
int lives=3;

//for gameover
int counter=0;
int dCounter=1;

//stating buttons
buttons tl,bl,tr,br;
questionBox a;


 

public void setup(){
  

  current=gameModes.Starting;

  // adding the background
}//end of setup()

public void draw_Player(int x,int y){
  x=0;
  y=0;
 int currentframe = frameCount%30; 
 
   if(currentframe < 15){
     PImage ally = loadImage("Guy1.png");
     image(ally,x+500,y+225);
   } else {
     
     PImage ally2 = loadImage("Guy2.png");
     image(ally2,x+500,y+225);
   }
   
   if(currentframe < 20){
    PImage enemy1 = loadImage("WOLF1.png");
     image(enemy1,x+265,y+225);
   
   }else{
     PImage enemy2 = loadImage("WOLF2.png");
     image(enemy2,x+265,y+225);
}
}



public void draw(){
    int x = 0;

    
  if(current==gameModes.Starting){
    PImage img= loadImage("Index.png");
    img.resize(200 ,557);
    image(img,x+30,50);
    PImage img2 = loadImage("Cadre.png");
    image(img2,x+250,50);
    PImage img3 = loadImage("Bbox.png");
    img3.resize(400, 150);
    image(img3,x+250,455);
    draw_Player(0,0);
   if(quest==1){
     a= new questionBox(263,100,"Which of these isn\u2019t an int value:");
     tl= new buttons(280,470,160,50,"a) 3");
     tr= new buttons(470,470,160,50,"b) 65");
     bl= new buttons(280,530,160,50,"c) 0");
     br= new buttons(470,530,160,50,"d) 8.9");
     textSize(20);
     text("Hint:\nDisplaying text:\nSystem.out.\nprintln('Hello');\noutput: Hello",50,105);
   }
    if(quest==2){
    a.text="Which of these is a double?";
    tl.awn="a) 9.12";
    tr.awn="b) ab";
    bl.awn="c) ?";
    br.awn="d) None";
    textSize(20);
    text("Hint:",50,105);
    textSize(17);
     text("\nint myNumber = 5;\ndouble d = 4.51;\nString text = 'Who?';",50,105);
    
   }
   if(quest==3){
    a.text="Where do we put a \u201c;\u201d in a line of\ncode:";
    a.boxH=140;
    tl.awn="Start";
    tr.awn="Centre";
    bl.awn="End";
    br.awn="None";
    textSize(20);
    text("Hint:",50,105);
    textSize(14);
     text("\nint a = 4;\nint b = 2;\nint c = 0;\nc = a + b; \u2039 c will be 6\nc = a \u2013 b; \u2039 c will be 2\nc = a / b; \u2039 c will be 2 \na = a + b; \u2039 a will be 6",50,105);
   }
   if(quest==4){
    a.text="What would \u201ca\u201d be when:\n   a=5+6";
    tl.awn="a)  11";
    tr.awn="b)  12";
    bl.awn="c)  13";
    br.awn="d)  21";
    textSize(20);
    text("Hint:",50,105);
    textSize(9);
    text("\nint a = 5;\nif (a == 5)\n{\nSystem.out.println(\u201ca is five, indeed!\u201d);\n} else\nSystem.out.println(\u201ca isn\u2019t five\u201d);\noutput: a is five, indeed!",50,105);
    textSize(9);
    text("\n\n\n\n\n\n\n\n\nint a = 4;\nif (a == 5)\n{\nSystem.out.println(\u201ca is five, indeed!\u201d);\n} else\nSystem.out.println(\u201ca isn\u2019t five\u201d);\noutput: a isn\u2019t five.",50,105);
   }

    if(quest==5){
    a.text="What data type can you put a text\nin?";
    tl.awn="String";
    tr.awn="Double";
    bl.awn="Integer";
    br.awn="Float";
    textSize(20);
    text("Hint:",50,105);
    textSize(17);
    text("\nint myNumber = 5;\ndouble d = 4.51;\nString text = 'Who?';",50,105);
   }
    if(quest==6){
      a.text="Impossable!";
      a.boxH=90;
      a.boxL=180;
    tl.awn="";
    tr.awn="";
    bl.awn="";
    br.awn=""; 
    }
    
   a.render();
   tl.update();
   tr.update();
   bl.update();
   br.update();
  }//end of current playing
  
    if(current==gameModes.Lost){

      PImage img5= loadImage("Game over1.png");
      PImage img6= loadImage("Game over2.png");
      img5.resize(700,650);
      img6.resize(700,650);
      
      counter=counter+dCounter;
      
      if(counter>=0 && counter<=5)
      {
        image(img5,0,0);
      }
      if(counter>5 && counter<=10)
      {
        image(img6,0,0);
      }
      if(counter<0 ||counter==10){
      dCounter=-dCounter;
    }
    }//end of lost
  
}//end of draw


public void mousePressed(){
///*
  switch (quest){
  case 1:
    if(bl.buttHover()==true || tr.buttHover()==true|| tl.buttHover()==true){
     for(int i=0;i<10;i++){
      background(255,0,0);}
     lives--;
    }
    if(br.buttHover()==true){
      quest++;}
    break;
  case 2:
    if(bl.buttHover()==true || tr.buttHover()==true|| br.buttHover()==true){
     for(int i=0;i<10;i++){
      background(255,0,0);}
      lives--;

   }
    if(tl.buttHover()==true){
      quest++;}
    break;
  case 3:
    if(br.buttHover()==true || tr.buttHover()==true|| tl.buttHover()==true){
      for(int i=0;i<10;i++){
      background(255,0,0);}
      lives--; 
 }
    if(bl.buttHover()==true){
      quest++;}
    break;
  case 4:
    if(bl.buttHover()==true || tr.buttHover()==true|| bl.buttHover()==true){
      for(int i=0;i<10;i++){
      background(255,0,0);}
      lives--;
    }
    if(tl.buttHover()==true){
      quest++;}
    break;
  case 5:
    if(bl.buttHover()==true || tr.buttHover()==true|| bl.buttHover()==true){
      for(int i=0;i<10;i++){
      background(255,0,0);}
      lives--;
    }
    if(tl.buttHover()==true)
    {quest++;}
    break;
  }
  if (lives==0)
  {
   current=gameModes.Lost; 
  }
}//end of mousPressed();

public void keyPressed(){if (current == gameModes.Lost); setup(); draw(); lives = 3; }
class buttons{
  int buttX, buttY;
  int lsize, hsize;
  boolean buttHover;
  String awn;
  
  
  buttons(int x, int y, int l, int h, String s){
    buttX=x;
    buttY=y;
    lsize=l;
    hsize=h;
    awn=s;
    
  }//end of button constructor
  public void update(){
    render();
    buttHover();
  }//end of update
  
  public void render(){
    stroke(255);
    fill(70, 81, 71);
    rect(buttX,buttY,lsize,hsize);
    fill(255);
    textSize(24);
    text(awn,buttX+(lsize/4)-15,buttY+(hsize/2)+10);
  }//end of render
  
public boolean buttHover()  {
  if (mouseX >= buttX && mouseX <= buttX+lsize && 
      mouseY >= buttY && mouseY <= buttY+hsize) {
    return true;
  } else {
    return false;
  }
}
  
}//end of button
class questionBox{
  int boxX;
  int boxY;
  String text;
  PImage img= loadImage("Copy of Qbox.png");
  int boxH=90;
  int boxL=370;
  
  questionBox(int x, int y, String s){
    boxX=x;
    boxY=y;
    text=s;

  }
  
    questionBox(int x, int y, String s, int z){
    boxX=x;
    boxY=y;
    text=s;
    boxH=z;
    img.resize(boxL ,boxH);
  }
  public void render(){
    img.resize(boxL ,boxH);
    image(img,boxX,boxY);
    fill(0);
    textSize(20);
    text(text,boxX+20,boxY+45); 
  }
  
}//end of questionBox
  public void settings() {  size(700, 650); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "project_hack2" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
